<?php
/*
Plugin Name:  _welearner _courses
Plugin URI:   
Description:  Adding Custom Post Types for _welearner
Version:      1.0.0
Author:       Golzar Ahamed Shohel
Author URI:   https://designxbd.com
License:      GPL2
License URI:  https://www.gnu.org/licenses/gpl-2.0.html
Text Domain:  _welearner-_courses
Domain Path:  /languages
*/

if( !defined('WPINC')) {
    die;
}

include_once('includes/courses-post-type.php');
include_once('includes/courses-tax.php');
include_once('includes/counter.php');
include_once('includes/testimonial.php');
include_once('includes/creator.php');

function _welearner__courses_activate() {
    _welearner__courses_setup_post_type();
    _welearner__courses_register_course_topic_tax();
    _welearner__counter_custom_post_type();
    _welearner__testimonial_custom_post_type();
    _welearner__creator_custom_post_type();
    flush_rewrite_rules();
}

register_activation_hook(__FILE__, '_welearner__courses_activate');

function _welearner__courses_deactivate() {
    unregister_post_type('_welearner_courses');
    unregister_taxonomy('_welearner_course_topic');
	unregister_post_type('__welearner_counter');
	unregister_post_type('__welearner_test');
	unregister_post_type('__welearner_creator');

    flush_rewrite_rules();
}

register_deactivation_hook(__FILE__, '_welearner__courses_deactivate');