<?php

function _welearner__courses_register_course_topic_tax() {
    $labels = [
        'name'              => esc_html_x('Course Topics', 'taxonomy general name', '_welearner-_courses'),
		'singular_name'     => esc_html_x('Course Topics', 'taxonomy singular name', '_welearner-_courses'),
		'search_items'      => esc_html__('Search Course Topicss', '_welearner-_courses'),
		'all_items'         => esc_html__('All Course Topics', '_welearner-_courses'),
		'parent_item'       => esc_html__('Parent Course Topics', '_welearner-_courses'),
		'parent_item_colon' => esc_html__('Parent Course Topics:', '_welearner-_courses'),
		'edit_item'         => esc_html__('Edit Course Topics', '_welearner-_courses'),
		'update_item'       => esc_html__('Update Course Topics', '_welearner-_courses'),
		'add_new_item'      => esc_html__('Add New Course Topics', '_welearner-_courses'),
		'new_item_name'     => esc_html__('New Course Topics Name', '_welearner-_courses'),
		'menu_name'         => esc_html__('Course Topicss', '_welearner-_courses'),
    ];
    $args = array(
        'labels' => $labels,
        'hierarchical' => true,
        'show_admin_column' => true,
        'rewrite' => array('slug' => 'course_topic')
    );
    register_taxonomy('_welearner_course_topic', ['_welearner_courses'], $args);
}

add_action('init', '_welearner__courses_register_course_topic_tax');