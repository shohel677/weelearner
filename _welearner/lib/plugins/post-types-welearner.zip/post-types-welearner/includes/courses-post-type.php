<?php

function _welearner__courses_setup_post_type() {

    $labels = array(
        'name'                  => esc_html_x( 'Course', 'Post type general name', '_welearner-_courses' ),
        'singular_name'         => esc_html_x( 'Courses ', 'Post type singular name', '_welearner-_courses' ),
        'menu_name'             => esc_html_x( 'Courses', 'Admin Menu text', '_welearner-_courses' ),
        'name_admin_bar'        => esc_html_x( 'Courses ', 'Add New on Toolbar', '_welearner-_courses' ),
        'add_new'               => esc_html__( 'Add New', '_welearner-_courses' ),
        'add_new_'          	=> esc_html__( 'Add New Courses ', '_welearner-_courses' ),
        'new_'              	=> esc_html__( 'New Courses ', '_welearner-_courses' ),
        'edit_'            	 	=> esc_html__( 'Edit Courses ', '_welearner-_courses' ),
        'view_'             	=> esc_html__( 'View Courses ', '_welearner-_courses' ),
        'view_'            		=> esc_html__( 'View Courses ', '_welearner-_courses' ),
        'all_'             		=> esc_html__( 'All Courses ', '_welearner-_courses' ),
        'search_'          		=> esc_html__( 'Search Courses ', '_welearner-_courses' ),
        'parent__colon'     	=> esc_html__( 'Parent Courses :', '_welearner-_courses' ),
        'not_found'             => esc_html__( 'No Courses  found.', '_welearner-_courses' ),
        'not_found_in_trash'    => esc_html__( 'No Courses  found in Trash.', '_welearner-_courses' ),
        'featured_image'        => esc_html_x( 'Courses  Image', 'Overrides the “Featured Image” phrase for this post type. Added in 4.3', '_welearner-_courses' ),
        'set_featured_image'    => esc_html_x( 'Set courses  image', 'Overrides the “Set featured image” phrase for this post type. Added in 4.3', '_welearner-_courses' ),
        'remove_featured_image' => esc_html_x( 'Remove courses  image', 'Overrides the “Remove featured image” phrase for this post type. Added in 4.3', '_welearner-_courses' ),
        'use_featured_image'    => esc_html_x( 'Use as courses  image', 'Overrides the “Use as featured image” phrase for this post type. Added in 4.3', '_welearner-_courses' ),
        'archives'              => esc_html_x( 'Courses archives', 'The post type archive label used in nav menus. Default “Post Archives”. Added in 4.4', '_welearner-_courses' ),
        'insert_into_'      	=> esc_html_x( 'Insert into courses ', 'Overrides the “Insert into post”/”Insert into page” phrase (used when inserting media into a post). Added in 4.4', '_welearner-_courses' ),
        'uploaded_to_this_' 	=> esc_html_x( 'Uploaded to this courses ', 'Overrides the “Uploaded to this post”/”Uploaded to this page” phrase (used when viewing media attached to a post). Added in 4.4', '_welearner-_courses' ),
        'filter__list'     		=> esc_html_x( 'Filter courses  list', 'Screen reader text for the filter links heading on the post type listing screen. Default “Filter posts list”/”Filter pages list”. Added in 4.4', '_welearner-_courses' ),
        '_list_navigation' 		=> esc_html_x( 'Courses  list navigation', 'Screen reader text for the pagination heading on the post type listing screen. Default “Posts list navigation”/”Pages list navigation”. Added in 4.4', '_welearner-_courses' ),
        '_list'            		=> esc_html_x( 'Courses  list', 'Screen reader text for the  list heading on the post type listing screen. Default “Posts list”/”Pages list”. Added in 4.4', '_welearner-_courses' ),
    );

    $args = array(
        'labels' => $labels,
        'public' => true,
        'has_archive' => true,
        'menu_icon' => 'dashicons-format-aside',
		'show_in_rest' => true,
        'supports' => array('title', 'editor', 'author', 'thumbnail', 'excerpt', 'comments'),
        'rewrite' => array('slug' => 'courses')
    );
    register_post_type('_welearner_courses', $args);
}

add_action('init', '_welearner__courses_setup_post_type');

